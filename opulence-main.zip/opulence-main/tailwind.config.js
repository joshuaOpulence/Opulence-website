/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./resources/**/*.blade.php",
        "./resources/**/*.js",
        "./resources/**/*.vue",
    ],
    theme: {
        extend: {
            colors: {
                bas: "#055C9D",
                grey3: "#FAFAFA",
                d6: "#D6D6D6",
                mint: "#F2F2F2",
                grey4: "#787878",
                grey5: "#565656",
                grey7: "#232323",
                lite: "#F6F9FF",
                lite1: "#FDFDFD",
                fin: "#D7E3F0",
                fint: "#0A3167",
                prime: "#044D83",
                purple: "#391CCF",
                purp: "#E4E2EF",
                red: "#CF0500",
                roon: "#FBDCDD",
                blut: "#2A4F74",
                blint: "#39596833",
                second: "#32AFB5",
                grain: "#F4FBFB",
                cova: "#E7F0F0",
                bud: "#F5F5F5",
                f8: "#F8F8F8",
                secon: "#D6EFF0",
                bid: "#48C1C7",
                oran: "#F76923",
            },
            fontSize: {
                1.5: "6px",
                1: "10px",
                2: "28px",
                3: "32px",
                4: "40px",
            },
            backgroundImage: {
                gradient:
                    "linear-gradient(344deg, #F6F9FF 12.1%, rgba(246, 249, 255, 0.00) 100.78%)",
            },
            fontFamily: {
                outfit: ["Outfit', sans-serif"],
            },
        },
    },
    plugins: [],
};

