@extends('layout.app')
@section('body')
<x-partials.navbar>
    <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6 bg-grey3 md:bg-transparent md:hover:bg-transparent  hover:bg-grey3" aClass="text-bas" />
    <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-grey5" />
    <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
    <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
</x-partials.navbar>
<section class="w-full" id="animated-section">
    
    <main class="px-4 md:px-12 lg:relative  lg:px-20 lg:h-screen pt-32 pb-10 md:pt-36 bg-gradient lg:pt-40 ">
        <div class="py-5 md:flex justify-between w-full  rounded-md h-full">
            <div class="lg:mt-20 flex-grow text-center sm:text-left">
               <div class="lg:flex space-x-8">
                    <h1 class="text-grey7 text-2xl md:text-4xl font-medium lg:text-6xl md:tracking-wider md:leading-10">
                        Revolutionizing Multiple <br class="hidden md:inline"> Industries with <span class="text-bas">Innovative </span><br class="hidden md:inline">Tech <span class="text-bas">Solutions</span>
                    </h1>
                    <img src="{{asset('asset/plane.svg')}}" alt="" class="hidden lg:inline">
               </div>
                <p class="mt-4 md:mt-6 text-base md:text-2xl font-light">
                    A conglomerate of tech solutions that deliver tremendous value to  users  <br class="hidden md:inline"> across various sectors
                </p>
                <button class="text-white px-7 md:text-lg md:px-12 py-4 bg-bas mt-10 lg:mt-16 rounded-full">
                    Our solution
                </button>
            </div>
            <div class="mt-12 md:mt-0 px-8 md:px-0 relative md:static">
                <img src="{{asset('asset/hero.svg')}}" alt="">
                <img src="{{asset('asset/star.png')}}" alt="" class="md:hidden inline absolute right-5 bottom-0 scale-50">
                <img src="{{asset('asset/plane.svg')}}" alt="" class="md:hidden inline absolute left-2 top-3 h-8">
            </div>
            <a href="#col" class="hidden lg:inline absolute left-1/2 bottom-24">
                <svg width="67" height="114" viewBox="0 0 67 114" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g id="draw">
                        <path d="M33.1236 54.3336L41.172 46.296C41.2501 46.2175 41.3432 46.1554 41.4458 46.1135C41.5483 46.0716 41.6583 46.0507 41.769 46.052C41.8798 46.0534 41.9892 46.0769 42.0907 46.1213C42.1922 46.1657 42.2838 46.23 42.36 46.3104C42.5161 46.4749 42.602 46.6938 42.5993 46.9205C42.5966 47.1473 42.5056 47.3641 42.3456 47.5248L33.702 56.1564C33.6244 56.2345 33.5321 56.2963 33.4304 56.3383C33.3286 56.3803 33.2195 56.4016 33.1095 56.4009C32.9994 56.4002 32.8906 56.3776 32.7894 56.3344C32.6882 56.2912 32.5966 56.2282 32.52 56.1492L23.646 47.064C23.4889 46.9014 23.4012 46.6841 23.4012 46.458C23.4012 46.2319 23.4889 46.0146 23.646 45.852C23.7232 45.7725 23.8155 45.7094 23.9175 45.6662C24.0196 45.6231 24.1292 45.6008 24.24 45.6008C24.3508 45.6008 24.4604 45.6231 24.5625 45.6662C24.6645 45.7094 24.7568 45.7725 24.834 45.852L33.1236 54.3336Z" fill="#32AFB5"/>
                    </g>
                    <g id="rect1">
                        <rect x="29" y="24" width="8" height="18" rx="4" fill="#32AFB5"/>
                    </g>
                    <g id="rect2">
                        <rect x="2" y="2" width="63" height="110" rx="31.5" stroke="#32AFB5" stroke-width="4"/>
                    </g>
                </svg>
            </a>
        </div> 
        <img src="{{asset('asset/star.png')}}" alt="" class="hidden lg:inline absolute right-10 bottom-10 animated-element"> 
    </main>
</section>
<section class="px-0 py-8 md:py-8 lg:py-10 lg:px-20" id="col" id="animated-section">
    <div>
        <h3 class="px-4 text-grey7 text-lg md:text-2xl font-normal">
            OUR COLLABORATORS 
        </h3>
        <div class="overflow-x-auto lg:overflow-x-hidden">
            <div class="flex items-center md:justify-between mt-4 md:mt-11">
                <img src="{{asset('asset/visa.png')}}" alt="" class="scale-50 md:scale-75 lg:scale-100">
                <img src="{{asset('asset/fintrac.png')}}" alt="" class="scale-50 md:scale-75 lg:scale-100">
                <img src="{{asset('asset/treasury.png')}}" alt="" class="scale-50 md:scale-75 lg:scale-100">
                <img src="{{asset('asset/kuda.png')}}" alt="" class=" scale-50 md:scale-75 lg:scale-100 ">
                <img src="{{asset('asset/ocean.png')}}" alt="" class="">
            </div>
        </div>      
    </div>
</section>
<section class="w-full px-4 py-14 md:py-12 md:px-12 lg:px-20 bg-lite">
    <div class="flex w-full justify-center relative mb-16">
        <div class="text-center">
            <h3 class="text-bas text-lg md:text-4xl">Our Products</h3>
            <p class="md:mt-6 text-sm md:text-base font-light">Check out our products below</p>
            <div class="svg-container hidden lg:inline absolute right-4 md:right-0 -top-3 md:top-3 h-4 h-10 lg:h-auto">
                <svg width="80" height="80" viewBox="0 0 80 80" fill="none" class="scale-50 " xmlns="http://www.w3.org/2000/svg">
                    <circle cx="75.9999" cy="41.1429" r="4" transform="rotate(90 75.9999 41.1429)" fill="#5892BE"/>
                    <circle cx="51.9999" cy="41.1429" r="4" transform="rotate(90 51.9999 41.1429)" fill="#5892BE"/>
                    <circle cx="27.9999" cy="41.1429" r="4" transform="rotate(90 27.9999 41.1429)" fill="#5892BE"/>
                    <circle cx="64.6477" cy="66.264" r="4" transform="rotate(135 64.6477 66.264)" fill="#5892BE"/>
                    <circle cx="47.6771" cy="49.2935" r="4" transform="rotate(135 47.6771 49.2935)" fill="#5892BE"/>
                    <circle cx="30.7065" cy="32.3229" r="4" transform="rotate(135 30.7065 32.3229)" fill="#5892BE"/>
                    <circle cx="38.8571" cy="76" r="4" transform="rotate(180 38.8571 76)" fill="#5892BE"/>
                    <circle cx="38.8571" cy="52" r="4" transform="rotate(180 38.8571 52)" fill="#5892BE"/>
                    <circle cx="38.8571" cy="28" r="4" transform="rotate(180 38.8571 28)" fill="#5892BE"/>
                    <circle cx="13.736" cy="64.6477" r="4" transform="rotate(-135 13.736 64.6477)" fill="#5892BE"/>
                    <circle cx="30.7065" cy="47.6771" r="4" transform="rotate(-135 30.7065 47.6771)" fill="#5892BE"/>
                    <circle cx="47.6771" cy="30.7066" r="4" transform="rotate(-135 47.6771 30.7066)" fill="#5892BE"/>
                    <circle cx="4" cy="38.8571" r="4" transform="rotate(-90 4 38.8571)" fill="#5892BE"/>
                    <circle cx="28" cy="38.8571" r="4" transform="rotate(-90 28 38.8571)" fill="#5892BE"/>
                    <circle cx="52" cy="38.8571" r="4" transform="rotate(-90 52 38.8571)" fill="#5892BE"/>
                    <circle cx="15.3523" cy="13.736" r="4" transform="rotate(-45 15.3523 13.736)" fill="#5892BE"/>
                    <circle cx="32.3229" cy="30.7066" r="4" transform="rotate(-45 32.3229 30.7066)" fill="#5892BE"/>
                    <circle cx="49.2934" cy="47.6771" r="4" transform="rotate(-45 49.2934 47.6771)" fill="#5892BE"/>
                    <circle cx="41.1428" cy="4" r="4" fill="#5892BE"/>
                    <circle cx="41.1428" cy="28" r="4" fill="#5892BE"/>
                    <circle cx="41.1428" cy="52" r="4" fill="#5892BE"/>
                    <circle cx="66.2639" cy="15.3524" r="4" transform="rotate(45 66.2639 15.3524)" fill="#5892BE"/>
                    <circle cx="49.2933" cy="32.3229" r="4" transform="rotate(45 49.2933 32.3229)" fill="#5892BE"/>
                    <circle cx="32.3228" cy="49.2934" r="4" transform="rotate(45 32.3228 49.2934)" fill="#5892BE"/>
                </svg>
            </div>
            <div class="lg:hidden svg-container inline absolute top-1 right-0 w-6 h-6"><img src="{{asset('asset/circ.png')}}" alt="" class=""></div>
        </div>
    </div>
    <div class="w-full grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="p-10 bg-lite1 rounded lg:px-10 lg:pt-12 lg:pb-16">
            <div class="">
               <img src="{{asset('asset/igoal.svg')}}" alt="">
            </div>
            <div class=" mt-3">
                <span class="text-sm text-fint rounded-full bg-fin py-1 px-8">FinTech</span>
            </div>
            <div class="mt-6">
                <p class="leading-relaxed text-sm md:text-base font-light">Our FinTech product, iGoal, helps user get the best value out of currency exchange. iGoal has a unique peer to peer exchange model that strategically reduces the cost of currency exchange and remittances to users in alignment with Sustainable Development Goals (SDGs).</p>
                <a href="https://igoal.finance" class="mt-8 text-prime text-sm md:text-base inline-flex items-center">Learn More
                    <svg width="11" height="12" viewBox="0 0 11 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-2">
                        <path id="Arrow 1" d="M11 1.5C11 0.947715 10.5523 0.5 10 0.5L1 0.5C0.447715 0.5 2.8711e-07 0.947715 2.8711e-07 1.5C2.8711e-07 2.05228 0.447715 2.5 1 2.5L9 2.5L9 10.5C9 11.0523 9.44772 11.5 10 11.5C10.5523 11.5 11 11.0523 11 10.5L11 1.5ZM1.70711 11.2071L10.7071 2.20711L9.29289 0.792893L0.292893 9.79289L1.70711 11.2071Z" fill="#044D83"/>
                    </svg>
                </a>
            </div>
        </div>
        <div class="p-10 bg-lite1 rounded lg:px-10 lg:pt-12 lg:pb-16">
            <div class="">
               <img src="{{asset('asset/vmoma.svg')}}" alt="">
            </div>
            <div class=" mt-3">
                <span class="text-sm text-purple rounded-full bg-purp py-1 px-8">SocialTech</span>
            </div>
            <div class="mt-6">
                <p class="leading-relaxed text-sm md:text-base font-light">Visionary Momas (VMomas) is a digital platform for moms to connect, share and leverage numerous support tools for intentional parenting. The objective of this solution is to create a platform that support moms on their parenting journey, to achieve a happy mom and a thriving child.</p>
                <a href="https://visionarymomas.com" class="mt-8 text-prime text-sm md:text-base inline-flex items-center">Learn More
                    <svg width="11" height="12" viewBox="0 0 11 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-2">
                        <path id="Arrow 1" d="M11 1.5C11 0.947715 10.5523 0.5 10 0.5L1 0.5C0.447715 0.5 2.8711e-07 0.947715 2.8711e-07 1.5C2.8711e-07 2.05228 0.447715 2.5 1 2.5L9 2.5L9 10.5C9 11.0523 9.44772 11.5 10 11.5C10.5523 11.5 11 11.0523 11 10.5L11 1.5ZM1.70711 11.2071L10.7071 2.20711L9.29289 0.792893L0.292893 9.79289L1.70711 11.2071Z" fill="#044D83"/>
                    </svg>
                </a>
            </div>
        </div>
        <div class="p-10 bg-lite1 rounded lg:px-10 lg:pt-12 lg:pb-16">
            <div class="">
               <img src="{{asset('asset/laybim.svg')}}" alt="">
            </div>
            <div class=" mt-3">
                <span class="text-sm text-red rounded-full bg-roon py-1 px-8">MediaTech</span>
            </div>
            <div class="mt-6">
                <p class="leading-relaxed text-sm md:text-base font-light">With Laybim (streaming), a content streaming solution, we provide high quality standards for content uploads as well as a decentralized model which enables content creators to start earning from their intellectual property from the get go. Viewers are also able to generate revenue from reviewing movies.</p>
                <a href="#" class="mt-8 text-prime text-sm md:text-base inline-flex items-center">Learn More
                    <svg width="11" height="12" viewBox="0 0 11 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-2">
                        <path id="Arrow 1" d="M11 1.5C11 0.947715 10.5523 0.5 10 0.5L1 0.5C0.447715 0.5 2.8711e-07 0.947715 2.8711e-07 1.5C2.8711e-07 2.05228 0.447715 2.5 1 2.5L9 2.5L9 10.5C9 11.0523 9.44772 11.5 10 11.5C10.5523 11.5 11 11.0523 11 10.5L11 1.5ZM1.70711 11.2071L10.7071 2.20711L9.29289 0.792893L0.292893 9.79289L1.70711 11.2071Z" fill="#044D83"/>
                    </svg>
                </a>
            </div>
        </div>
        <div class="p-10 bg-lite1 rounded lg:px-10 lg:pt-12 lg:pb-16">
            <div class="">
               <img src="{{asset('asset/tribe.svg')}}" alt="">
            </div>
            <div class=" mt-3">
                <span class="text-sm text-blut rounded-full bg-blint py-1 px-8">EduTech</span>
            </div>
            <div class="mt-6">
                <p class="leading-relaxed text-sm md:text-base font-light">OpEn Tribe is an all-encompassing  digital platform for aspiring entrepreneurs, startups, and solopreneurs to access a self-paced structured coaching, resource directory, and repository for business formation, scalability, profitability and sustainability.</p>
                <a href="https://courses.opulententrepreneurs.business/" class="mt-8 text-prime text-sm md:text-base inline-flex items-center">Learn More
                    <svg width="11" height="12" viewBox="0 0 11 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-2">
                        <path id="Arrow 1" d="M11 1.5C11 0.947715 10.5523 0.5 10 0.5L1 0.5C0.447715 0.5 2.8711e-07 0.947715 2.8711e-07 1.5C2.8711e-07 2.05228 0.447715 2.5 1 2.5L9 2.5L9 10.5C9 11.0523 9.44772 11.5 10 11.5C10.5523 11.5 11 11.0523 11 10.5L11 1.5ZM1.70711 11.2071L10.7071 2.20711L9.29289 0.792893L0.292893 9.79289L1.70711 11.2071Z" fill="#044D83"/>
                    </svg>
                </a>
            </div>
        </div>
       
    </div>
</section>
<section class="px-4 md:px-12 py-5 bg-white lg:px-24 lg:py-16">
  <div class="">
    <h1 class="text-bas text-3xl title-font font-medium mb-6">About Us</h1>
    <div class="w-full flex flex-wrap justify-between">
      <div class="lg:w-1/2 w-full order-2 lg:order-1">
        <p class="leading-relaxed text-sm md:text-lg text-grey5 font-light">We are a dynamic, multi-sectored technology company driven by a visionary commitment to creating sustained and globally impactful change through diversified technological innovation.</p>
        <p class="leading-relaxed mt-6 text-sm md:text-lg text-grey5 font-light">Our firm is currently headquartered in Canada, with established subsidiaries in the United States and Africa.</p>
        <p class="leading-relaxed mt-6 text-sm md:text-lg text-grey5 font-light">As part of our ambitious journey, we are steadfastly pursuing a mission of progressive expansion into additional global markets. Our passion for innovation knows no bounds, and we are dedicated to pioneering solutions that shape a brighter future for all.</p>
      </div>
      <div class="lg:w-1/2 w-full lg:flex justify-end order-1 lg:order-2 mb-8 lg:mb-0">
        <div class="">
            <img  class="object-cover object-center rounded" src="{{asset('asset/about1.png')}}" class="">
            <img  class="object-cover object-center rounded" src="{{asset('asset/about2.png')}}" class="">
        </div>
      </div>
      
    </div>
  </div>
</section>
<section class="px-4 md:px-12 py-10 lg:px-24 lg:mt-14 lg:pb-16">
    <div class="w-full relative flex justify-center items-center">
        <div class="flex items-center">
           <h3 class="text-bas text-lg md:text-4xl">Our Guiding Principles</h3> 
           <img src="{{asset('asset/plane2.svg')}}" alt="" class="ml-4 scale-50 lg:scale-100 lg:ml-14">
        </div>
    </div>
    <div class="mt-10 lg:mt-20 grid grid-cols-1 lg:grid-cols-3 px-4 md:px-6 gap-y-12 md:gap-x-8">
        <div class="pr-4 flex justify-center lg:block">
            <div class="">
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/justice.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-grey7 text-base md:text-2xl">Inte</span><span class="md:text-2xl text-base text-bas">grity</span>
                </div>
                <p class="tex-sm md:text-lg text-center lg:text-left text-grey5 font-light mt-5">
                    We don't make empty promises to our valued customers, dedicated employees, trusted collaborators, or the communities we serve. We take commitments seriously, and our word is our bond.
                </p>
             
            </div>
        </div>
        <div class="lg:pl-4 lg:border-l flex justify-center lg:block">
            <div class="">
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/care.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-grey7 text-base md:text-2xl">Maximum</span><span class="md:text-2xl ml-1 text-base text-second">value</span>
                </div>
                <p class="tex-sm md:text-lg text-center lg:text-left text-grey5 font-light mt-5">
                    We are strongly guided by the principle of maximum value creation in all our endeavors and relationships. When creating products, standards, and policies, our passion for value creation serves as a key compass.
                </p>
            </div>
        </div>
        <div class="lg:pl-4 lg:border-l flex justify-center lg:block">
            <div class="">
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/thumb.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-bas text-base md:text-2xl">Possi</span><span class="md:text-2xl text-base text-grey7">bilities</span>
                </div>
                <p class="tex-sm md:text-lg text-center lg:text-left text-grey5 font-light mt-5">
                    We are driven by a mindset of endless possibilities, which informs our commitment to technology and innovation. At Opulence Capital, it is never a question of whether something is doable; the focus is always on what is required to get it done.
                </p>
            </div>
        </div>
        <hr class="lg:inline hidden mr-5a">
        <hr class="lg:inline hidden ml-8">
        <hr class="lg:inline hidden ml-8">
        <div class="lg:pr-4 flex justify-center lg:block ">
            <div class="">
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/idea.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-grey7 text-base md:text-2xl">Inno</span><span class="md:text-2xl text-base text-second">vation</span>
                </div>
                <p class="tex-sm md:text-lg text-center lg:text-left text-grey5 font-light mt-5">
                    Our commitment to innovation is unwavering. We embrace it as the heartbeat of our organization, the lifeblood of our growth, and the foundation of our success. In everything we do, we seek new and inventive ways to improve.
                </p>
                
            </div>
        </div>
        <div class="lg:pl-4 lg:border-l flex justify-center lg:block ">
            <div class="">
                
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/good.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-bas text-base md:text-2xl">Excel</span><span class="md:text-2xl text-base text-grey7">lence</span>
                </div>
                <p class="tex-sm md:text-lg text-center lg:text-left text-grey5 font-light mt-5">
                   Excellence fuels our ambition and shapes our vision. It's the driving force that propels us to push boundaries, challenge the status quo, and exceed expectations. It's the commitment we make to ourselves, our team, and our valued customers
                </p>
            </div>
        </div>
        <div class="lg:pl-4 lg:border-l flex justify-center lg:block">
            <div class="">
                <div class="flex justify-center lg:block">
                    <img src="{{asset('asset/medal.svg')}}" alt="">
                </div>
                <div class="mt-3 text-center lg:text-left">
                    <span class="text-second text-base md:text-2xl">Pace</span><span class="md:text-2xl text-base text-bas">-setting</span>
                </div>
                <p class="tex-sm md:text-lg text-grey5 font-light mt-4 md:mt-5 text-center lg:text-left">
                   In a world that's constantly evolving, we don't wait for change to happen; we drive it. We're the ones who raise the bar, challenge the status quo, and inspire others to follow. We don't just keep up with the times, we set the pace for them
                </p>
            </div>
        </div>
    </div>
</section>
<section class="px-4 md:px-12 py-10 lg:py-16 lg:px-24 lg:pb-16 bg-grain">
    <div>
        <h3 class="text-bas text-center text-lg md:text-4xl">Our Team</h3>
        <p class="text-grey5 text-sm lg:text-lg text-center font-light mt-4 md:mt-6">Our team is made of brilliant minds with years of experience, various certifications of their expertise, <br class="hidden lg:inline"> and character. Opulence Capital is powered by of value-driven individuals. </p>
    </div>
    <div class="py-8 lg:px-44 lg:my-24">
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10 lg:gap-x-11 lg:gap-y-16">
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/fem.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Olufemi Ibitoye</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">CEO</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/tolu.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Tolulope Olumilua</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Founder & COO</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/josh.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-2 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Joshua Oyeshola</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">IT Project and Product Manager</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/gbenga.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Gbenga Oshin</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Legal and Compliance Associate</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/kemi.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Oluwakemi Daramola</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Enterprise Relationship Manager</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/abbah.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <div class="flex justify-center space-x-1">
                        <h2 class="text-sm md:text-base text-grey7 mb-1.5">Abah Joseph</h2>
                        <img src="{{asset('asset/cc.svg')}}" alt="">
                    </div>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Head of Technology Infrastructure Securtiy</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/sam.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-3 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Samuel Akanbi</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Creative Lead</h3>
                </div>
            </div>
            <div class="team shadow">
                <div class="flex flex-col items-center text-center bg-cova rounded-t-xl">
                    <div class="py-3 md:py-4">
                        <img src="{{asset('asset/kins.png')}}" alt="team-image">
                    </div>
                </div>
                <div class="w-full bg-white text-center px-1 py-3 md:py-4">
                    <h2 class="text-sm md:text-base text-grey7 mb-1.5">Kingsley Offor</h2>
                    <h3 class="text-grey7 text-xs md:text-sm font-light">Finance Associate</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<x-partials.footer/>
@endsection