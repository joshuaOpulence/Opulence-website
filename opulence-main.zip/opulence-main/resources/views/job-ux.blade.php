@extends('layout.app')
@section('body')
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-bas" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
    </x-partials.navbar>
    <div class="lg:flex w-full justify-center px-4 mt-28 py-6 md:px-12 lg:px-0 md:py-10 lg:py-16">
      <article class="lg:w-4/5">
       <div class="w-full flex justify-center">
        <div class="flex flex-col items-center">
          <h1 class="text-grey7 font-medium text-2 lg:text-4 text-center">UI/UX Designer</h1>
          <div class="flex text-sm md:text-base font-light text-grey5 mb-4">
            <span class="px-4 text-center">Remote</span> 
            <span class="px-4 text-center border-l border-bud">Full-time</span> 
          </div> 
          <div class="flex justify-center mt-8 lg:mt-14 ">
           <x-partials.apply/>
          </div>
        </div>
       </div>

       <div class="mt-9 md:mt-14">
        <h3 class="text-grey7 text-lg lg:text-2xl">Working at Opulence Capital Investments</h3>
        <div class="mt-4 md:mt-6">
          <p class="text-grey5 font-light text-sm lg:text-lg">
           At Opulence Capital Investments, we foster a work culture that stands as a shining example of excellence and inclusivity. Our commitment to cultivating a positive and productive environment is ingrained in every aspect of our operations. Here's what makes our work culture exceptional:
          </p>
          <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Diverse Inclusion:</span> We celebrate diversity's strength, fostering a vibrant team with talents from varied backgrounds, driving innovation and a welcoming atmosphere.</p>
          <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Collaborative Heart:</span>  Our culture thrives on collaboration, promoting open communication and teamwork to conquer complex challenges collectively.</p>

          <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Lifelong Learning:</span> We invest in continuous learning, empowering employees to reach their potential through training and development programs.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Work-Life Balance:</span> Work-Life Balance: Valuing well-being, we support flexible working arrangements, enabling personal and professional growth.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Transparency:</span> Trust is paramount; we maintain transparency in decision-making, finances, and company goals.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Career Growth:</span> Our culture prioritizes career progression, offering mentorship, reviews, and advancement opportunities.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Ethical Standards:</span> We uphold integrity and ethical behavior, fostering trust and respect.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6"><span class="font-medium">Employee Well-Being:</span> We invest in wellness programs, supporting mental health and stress management.</p>

         <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">In summary, Opulence Capital Investments' culture is a testament to our commitment to a workplace where talent thrives, ideas prosper, and everyone feels valued. This culture is the bedrock of our success, continuously nurtured to make our workplace a second home for our remarkable team.</p>
        </div>
       </div>

       <div>
        <h3 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">What we are looking for</h3>
        <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
    
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">4 years + professional UX / product design experience, with at least some familiarity of Jira products.</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">An eye for detail, with a customer-centric lens.</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Ability to define projects and measures of success, test your assumptions and outcomes, and continuously incorporate feedback.</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Comfortable conducting and summarizing insights from qualitative and quantitative research.</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Strong Figma proficiency and experience with interface design</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience collaborating successfully with designers, developers, product managers, and other team members.</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Opportunity to grow to form a strong team of designers. Our team moves fast, and there’s always something to learn!</li>
          <li class="list-disc text-sm font-light text-grey5 md:text-lg">Last but not least, a healthy amount of disregard of the status quo </li>
        </ul>
       </div>

       <div>
        <h3 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Nice to have</h3>
        <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
         <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience in startups or scaleups</li>
         <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience with Lean UX and rapid customer delivery</li>
         <li class="list-disc text-sm font-light text-grey5 md:text-lg">An interest in team-building</li>
         <li class="list-disc text-sm font-light text-grey5 md:text-lg">A healthy tolerance for ambiguity</li>
        </ul>

       </div>

       <div>
        <h3 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Nice to have</h3>
        <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">Opulence Capital Investments offers a variety of perks and benefits to support you, your family and to help you engage with your local community. Our offerings include health coverage, paid volunteer days, wellness resources, and so much more.</p>
       </div>
       <div class="flex justify-center mt-8 lg:mt-14 ">
          <x-partials.apply/>
        </div>
      </article>
    </div>
    
</section>
<x-partials.footer/>
@endsection