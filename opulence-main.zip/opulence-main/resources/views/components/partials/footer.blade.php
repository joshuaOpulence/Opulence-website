<footer class="px-4 py-10 md:px-12 lg:py-16 lg:px-24 lg:pb-16 bg-white">
    <div class="w-full space-y-6 md lg:flex justify-between border-b border-bud lg:border-none">
        <div>
            <h3 class="text-bas text-lg md:text-4xl">Stay in touch and informed!</h3>
            <p class="text-grey5 text-sm lg:text-lg font-light mt-4 md:mt-5">
                Our help center operates around the clock. If you don't find the answer you need here, simply complete our <br class="hidden md:inline"> contact form, and we'll promptly respond to your inquiry.
            </p>
            <div class="mt-11 flex space-x-6">
                <a href="{{route('contact')}}" class="bg-bas px-7 rounded-full py-3 text-sm md:text-base text-white">
                    Contact us
                </a>
                <a href="{{route('blog')}}" class="flex space-x-2 md:space-x-3 items-center">
                    <span>Visit our  blog</span>
                    <img src="{{asset('asset/more.svg')}}" alt="">
                </a>
            </div>
        </div>
        <div class="lg:pr-6 flex justify-center lg:block">
            <img src="{{asset('asset/iso.svg')}}" alt="" class="scale-50 md:scale-75 lg:scale-100">
        </div>
    </div>
    <div class="text-grey5 text-sm lg:text-lg font-light mt-4 lg:mt-12">
        Opulence Capital Investments Ltd. is a licensed Money Service Business (MSB)- <br class="hidden lg:inline"> #31000246008307 in USA, regulated by FINCEN & #M22324129 regulated by FINTRAC in Canada
    </div>
    <div class="w-full mt-6 lg:mt-10 flex flex-col lg:flex-row lg:justify-between">
        <span class="order-2 lg:order-1 font-light text-center lg:text-left text-sm md:text-base text-grey7">&copy; Copyrights 2023 Opulence Capital Investments</span>
        <div class="flex flex-col lg:flex-row space-y-5 lg:space-y-0 lg:space-x-8 items-center lg:items-start lg:order-2 order-1 mb-8 lg:mb-0">
            <a href="{{route('privacy')}}" class="text-bas text-sm md:text-base font-light md:font-normal">Privacy policy</a>
            <div class="flex items-center space-x-12 lg:space-x-8">
                <a href="https://youtube.com/@OpulenceCapital?si=-sUN7P_Jsedr0tTm">
                    <img src="{{asset('asset/youtube.svg')}}" alt="youtube-icon">
                </a>
                <a href="https://www.linkedin.com/in/opulence-capital-investments-ltd-5695ba24b/?originalSubdomain=ca">
                    <img src="{{asset('asset/linkedin.svg')}}" alt="linkedin-icon">
                </a>
                <a href="https://instagram.com/opulencecapitalinvestments?igshid=NTc4MTIwNjQ2YQ==">
                    <img src="{{asset('asset/instagram.svg')}}" alt="instagram-icon">
                </a>
                <a href="">
                    <img src="{{asset('asset/thread.svg')}}" alt="thread-icon">
                </a>
            </div>
        </div>
    </div>
</footer>