<nav class="w-full shadow-sm border-d6  bg-white fixed z-50 top-0  pt-10 sm:py-5 px-4 lg:px-20 md:py-4">
  <div class="w-full md:flex items-center justify-between lg:grid-cols-3">
    <div class="flex w-full md:w-auto md:block justify-between items-center">
      <a href="{{route('index')}}">
        <img src="{{asset('asset/logo.svg')}}" alt="" class="sm:w-auto sm:h-auto w-20 h-20">
      </a>
      <button id="menu-btn" class="bg-grey3 rounded-full p-2 inline-flex md:hidden">
        <img src="{{asset('asset/menu.svg')}}" alt="">
      </button>
    </div>
    <div class="hidden md:inline-flex w-full md:w-auto z-30 left-0 right-0 absolute md:static transition-all ease-in-out duration-700 menu">
      <ul class="md:flex items-center py-5 space-y-4 md:space-y-0 text-center bg-white md:text-left md:space-x-5 md:rounded-full md:bg-grey3 ">
        {{$slot}}
      </ul>
    </div>
    <div class="hidden lg:block"></div>
  </div>
</nav>
