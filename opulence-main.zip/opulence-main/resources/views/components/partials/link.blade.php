@props(['liClass' => '', 'aClass' => '', 'route', 'label'])

<li class="px-8 py-5 sm:py-0 hover:bg-grey3 md:hover:bg-transparent {{ $liClass }}">
  <a {{ $attributes->merge(['class' => 'text-base md:text-lg lg:hover:text-bas ' . $aClass]) }} href="{{ $route }}">
    {{ $label }}
  </a>
</li>

        



