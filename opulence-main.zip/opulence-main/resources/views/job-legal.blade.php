@extends('layout.app')
@section('body')
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-bas" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
    </x-partials.navbar>
    <div class="lg:flex w-full justify-center px-4 mt-28 py-6 md:px-12 lg:px-0 md:py-10 lg:py-16">
      <article class="lg:w-4/5">
       <div class="w-full flex justify-center">
        <div class="flex flex-col items-center">
          <h1 class="text-grey7 font-medium text-2 lg:text-4 text-center">Legal & Compliance Associate</h1>
          <div class="flex text-sm md:text-base font-light text-grey5 mb-4">
            <span class="px-4">Remote</span> 
            <span class="px-4 border-l border-bud">Full-time</span> 
          </div> 
          <div class="flex justify-center mt-8 lg:mt-14 ">
           <x-partials.apply/>
          </div>
        </div>
       </div>

       <div class="mt-9 md:mt-14">
        <h3 class="text-grey7 text-lg lg:text-2">Working at Opulence Capital Investments</h3>
        <div class="mt-4 md:mt-6">
          <p class="text-grey5 font-light text-base lg:text-lg "><span class="font-medium">Reporting to:</span> Chief Operations Officer</p>
          <div>
            <h3 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Responsibilities:</h3>
            <h4 class="text-grey5 text-sm lg:text-lg mt-4 md:mt-6">SECRETARIAL Duties;</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg"> Assist in setting up and registering the company in accordance with corporate , international and market-specific laws and  regulations.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Maintain statutory books, registers and records.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Prepare and file necessary documents with regulatory authorities, including but not limited to annual returns and resolutions.</li>
            </ul>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">AML/CFT COMPLIANCE duties;</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg"> Continuos and Routine audit of the company's  cross-functional policies, procedures, and controls, especially AML/CFT policies, procedures and controls.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Develop and implement robust AML/CFT compliance programs tailored towards your specific operations and risk profile.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Provide ongoing monitoring, reporting and advisory services to ensure compliance with applicable AML/CFT regulations. </li>
            </ul>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">LEGAL ADVISORY</h4>
            <ol class="space-y-4 px-6 md:px-8 mt-4 md:mt-6 ">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Offer legal guidance and support on a wide range of issues, including contract drafting and negotiation, intellectual property protection, data privacy, and cybersecurity.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Conduct legal due diligence for possible mergers, acquisitions, and investment transactions.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Provide legal opinions and advice on regulatory compliance issues.</li>
            </ol>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">LEGAL-TECH Duties</h4>
            <ul class="space-y-4  mt-4 md:mt-6">
              <li class="text-sm font-light text-grey5 md:text-lg">Serve as the contributing stakeholder for  legal requirements for product design and development</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Conduct system testing to ascertain system compliance with regulatory requirements</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Trace legal requirements to business objectives</li>
            </ul>

            <h4 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">REQUIREMENTS</h4>
            <ul class="space-y-4  mt-4 md:mt-6">
              <li class="text-sm font-light text-grey5 md:text-lg">Bachelors Degree in Law with Expertise in  Corporate Law/ International Business Law/International Law</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Certificate of Training/Certification in AML/ATF/CFT</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Analytical skills</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Research oriented</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Tech Savvy</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Fast Learner</li>
              <li class="text-sm font-light text-grey5 md:text-lg">Growth Mindset</li>
            </ul>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">DESIRABLE</h4>
            <ul class="space-y-4  mt-4 md:mt-6">
              <li class="text-sm font-light text-grey5 md:text-lg">Experience in legal-tech</li>
            </ul>
          </div>
       </div>
       <div class="flex justify-center mt-8 lg:mt-14 ">
          <x-partials.apply/>
        </div>
      </article>
    </div>
    
</section>
<x-partials.footer/>
@endsection