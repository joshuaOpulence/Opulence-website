@extends('layout.app')
@section('body')
{{-- hero --}}
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6 bg-grey3 md:bg-transparent md:hover:bg-transparent  hover:bg-grey3" aClass="text-bas" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
    </x-partials.navbar>
 <main class="px-4 py-10 md:px-12 lg:px-20 mt-28 md:mt-32 lg:mt-40 ">
  <div class="w-full flex justify-center">
   <div class="w-full lg:h-4/5">
    <h1 class="text-bas text-center text-2xl md:text-4xl  font-medium lg:text-4 md:tracking-wider md:leading-10">
     Experience the work-life environment at Opulence <br class="hidden lg:inline">Capital Investments
    </h1> 
    <p class="text-base md:text-2xl font-light text-grey5 text-center mt-7">Where everyone feels at home, regardless of whether you are working from home or on-site.</p>
   </div>
  </div>
   
  <div class="mt-10">
   <div class="w-full">
    <img src="{{asset('asset/team.png')}}" alt="Career-section image" class="hidden md:inline-flex w-full">
    <img src="{{asset('asset/team-mobile.png')}}" alt="Career-section image" class="block md:hidden">
    <div class="mt-10">
     <h3 class="text-bas text-lg md:text-4xl">Become a part of our team</h3>
     <p class="text-grey5 font-light text-sm lg:text-lg mt-3 md:mt-6">Discover the right job fit for you, and apply</p>
    </div>
   </div>
  </div> 
 </main>
</section>
{{-- opening --}}
<section class="px-10 py-6 md:px-12 md:py-10 lg:py-16 lg:px-24 lg:pb-16 bg-lite">
    <div class="">
        <h3 class="text-bas text-center text-lg md:text-2xl">Job openings</h3>
    </div>
    <div class="py-8 lg:py-10 flex justify-center">
        <div class="flex-col lg:w-4/6 md:justify-center mx-auto md: flex md:flex-row md:flex-wrap  gap-y-8 md:gap-y-12 md:gap-x-8">
            {{-- openings --}}
            <div class="border border-mint rounded bg-white shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between md:justify-start md:space-x-12">
                 <p class="text-base text-grey7">UI/UX Designer</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="{{route('job-ux')}}" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
            <div class="border border-mint rounded bg-white shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between md:justify-start md:space-x-12">
                 <p class="text-base text-grey7">Financial Analyst</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="https://forms.gle/11DV5Y8tNdzfZxrh9" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
            <div class="border border-mint bg-white rounded shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between md:justify-start md:space-x-12">
                 <p class="text-base text-grey7">Cyber Sec. Expert</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="https://forms.gle/11DV5Y8tNdzfZxrh9" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
            <div class="border border-mint rounded bg-white shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between md:justify-start md:space-x-12">
                 <p class="text-base text-grey7">Front end Engineer</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="https://forms.gle/11DV5Y8tNdzfZxrh9" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
            <div class="border border-mint rounded bg-white shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between items-start md:justify-start md:space-x-12">
                 <p class="text-base text-grey7"> Performance Officer</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="{{route('job-planning')}}" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
            <div class="border border-mint rounded bg-white shadow-sm p-8 md:px-4 md:py-5">
                <div class="flex justify-between md:justify-start md:space-x-12">
                 <p class="text-base text-grey7">Compliance Associate</p>
                 <p class="bg-bas text-lite1 text-1 flex justify-center items-center font-medium py-1 px-2 rounded-full">Full time</p>
                </div>
                <p class="text-xs text-grey5 mt-2.5">Remote</p>
                <a href="{{route('job-legal')}}" class="flex items-center mt-10">
                 <span class="text-xs text-bas">View and apply</span>
                 <img src="{{asset('asset/more.svg')}}" alt="" class="ml-2">
                </a>
            </div>
        </div>
    </div>
</section>
{{-- why work with us --}}
<section class="px-4 py-6 md:px-12 lg:py-16 lg:px-24 lg:pb-16 bg-white">
  <div class="">
      <h3 class="text-bas text-center text-lg md:text-3">Why work with us?</h3>
  </div>
  <div class="mt-8 md:mt-12 flex-col flex md:flex-row md:flex-wrap lg:flex-nowrap justify-center gap-y-3 lg:gap-y-0 md:gap-x-8">
   <div class="md:w-4/5 lg:w-1/3 px-6 py-8 border border-bud rounded-xl shadow-sm">
    <div class="flex items-center space-x-4">
     <span class="md:text-lg text-grey7 text">Fast growing company</span>
     <img src="{{asset('asset/check.svg')}}" alt="check-icon">
    </div>
    <div class="mt-4">
     <p class="text-grey5 text-sm md:text-base font-light ">We're the embodiment of progress and evolution, where every day is an opportunity to push boundaries, break through barriers, and achieve greatness. As we surge ahead, we invite you to be part of our growth story. </p>
    </div>
   </div>
   <div class="md:w-4/5 lg:w-1/3 px-6 py-8 border border-bud rounded-xl shadow-sm">
    <div class="flex items-center space-x-4">
     <span class="md:text-lg text-grey7 text">Fast growing company</span>
     <img src="{{asset('asset/check.svg')}}" alt="check-icon">
    </div>
    <div class="mt-4">
     <p class="text-grey5 text-sm md:text-base font-light ">We're the embodiment of progress and evolution, where every day is an opportunity to push boundaries, break through barriers, and achieve greatness. As we surge ahead, we invite you to be part of our growth story. </p>
    </div>
   </div>
   <div class="md:w-4/5 lg:w-1/3 px-6 py-8 border border-bud rounded-xl shadow-sm">
    <div class="flex items-center space-x-4">
     <span class="md:text-lg text-grey7 text">Fast growing company</span>
     <img src="{{asset('asset/check.svg')}}" alt="check-icon">
    </div>
    <div class="mt-4">
     <p class="text-grey5 text-sm md:text-base font-light ">We're the embodiment of progress and evolution, where every day is an opportunity to push boundaries, break through barriers, and achieve greatness. As we surge ahead, we invite you to be part of our growth story. </p>
    </div>
   </div>
  </div>
</section>
<x-partials.footer/>
@endsection