@extends('layout.app')
@section('body')
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6 bg-grey3 md:bg-transparent md:hover:bg-transparent  hover:bg-grey3" aClass="text-bas" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
    </x-partials.navbar>
    <div class="px-4 mt-32 pb-10 md:px-12 lg:px-20 ">
     <div class="py-10 border-b border-bud">
      <h1 class="text-bas font-medium text-2 lg:text-4 text-center">Blog</h1>
      <p class="font-light text-grey5 text-base md:text-2xl text-center mt-4">Explore industry trends and life-enhancing tips on our blog, your sanctuary for fresh perspectives</p>
     </div>
     {{-- Content --}}
     {{-- recent post --}}
     <div class="mt-11">
      <h4 class=" text-grey5 text-base md:text-2xl">Most recent posts</h4>
      <div class="mt-10 grid grid-cols-1 gap-8 md:gap-5 md:grid-cols-2 lg:grid-cols-4">
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog1.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd expands <br class="hidden md:inline"> operations into the African market.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog3.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">The ideate process in the design thinking process is the most crucial step.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div> 
      </div>
     {{-- all post --}}
     <div class="mt-11 md:mt-16">
      <h4 class=" text-grey5 text-base md:text-2xl">All posts</h4>
      <div class="mt-10 grid grid-cols-1 gap-8 md:gap-5 md:grid-cols-2 lg:grid-cols-4">
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog1.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd expands <br class="hidden md:inline"> operations into the African market.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog3.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">The ideate process in the design thinking process is the most crucial step.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
     </div>
     <div class="w-ful md:flex justify-end mt-10">
      <nav class="flex items-center justify-between md:justify-end">
       <button><i class="fa-solid fa-chevron-left text-grey4"></i></button>
       <button class="text-grey4 md:ml-4">Previous</button>
       <button class="text-sm w-8 md:ml-6 h-8 flex justify-center items-center rounded-full bg-bud">1</button>
       <button class="text-sm w-8 md:ml-6 h-8 flex justify-center items-center rounded-full bg-bud">2</button>
       <button class="text-sm w-8 md:ml-6 h-8 flex justify-center items-center rounded-full bg-bud">3</button>
       <span class="text-sm w-8 h md:ml-6 h-8 flex justify-center items-end rounded-full bg-">...</span>
       <button class="text-bas md:ml-6">Next</i></button>
       <button><i class="fa-solid ml-4 fa-chevron-right text-bas"></i></button>
      </nav>
     </div>
    </div>
</section>
<x-partials.footer/>
@endsection