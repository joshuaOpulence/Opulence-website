@extends('layout.app')
@section('body')
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-bas" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
    </x-partials.navbar>
    <div class="lg:flex w-full justify-center px-4 mt-28 py-6 md:px-12 lg:px-0 md:py-10 lg:py-16">
      <article class="lg:w-4/5">
       <div class="w-full flex justify-center">
        <div class="flex flex-col items-center">
          <h1 class="text-grey7 font-medium text-2 lg:text-4 text-center">Title: Strategy, Planning and Performance Officer</h1>
          <div class="flex text-sm md:text-base font-light text-grey5 mb-4">
            <span class="px-4">Remote</span> 
            <span class="px-4 border-l border-bud">Full-time</span> 
          </div> 
          <div class="flex justify-center mt-8 lg:mt-14 ">
           <x-partials.apply/>
          </div>
        </div>
       </div>

       <div class="mt-9 md:mt-14">
        <h3 class="text-grey7 text-lg lg:text-2">Working at Opulence Capital Investments</h3>
        <div class="mt-4 md:mt-6">
          <p class="text-grey5 font-light text-base lg:text-lg "><span class="font-medium">Reporting to:</span> Chief Operations Officer</p>
          <div>
            <h3 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Main duties and responsibilities</h3>
            <h4 class="text-grey7 text-sm lg:text-lg mt-4 md:mt-6">Corporate Planning</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Coordinate and deliver standard operating procedures for enterprise and functional practices.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Proactively liaise with functional stakeholders to establish and support the preparation of guidance and planning timelines;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Proactively work with functional stakeholders to ensure understanding of strategy, planning and performance processes, provision of supporting guidance, data, planning information, and communication of expectations;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Co-ordinate production of planning documents and their communication to relevant stakeholders;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Actively monitor planning activity and review systems and processes to ensure successful execution and process improvement;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Ensure outcomes of the processes are communicated to relevant groups, committees and stakeholders;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Support and contribute to the fundamental review of the company’s corporate and business planning processes and integration of planning across all areas of activity.</li>
            </ul>

            <h4 class="text-grey7 text-sm lg:text-lg mt-6 md:mt-8">Strategy and Performance</h4>
            <p class="text-grey5 text-sm font-light lg:text-lg mt-4 md:mt-6">Identify and communicate critical success factors cross-functionally, and customize mechanisms for tracking them as KPIs.</p>
            <h4 class="text-grey5 text-sm lg:text-lg mt-4 md:mt-6">Monitoring and Reporting</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Oversee reporting of strategic KPIs to the board of directors.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Produce regular performance reports to ensure information is effectively communicated and understood, including working with other functional stakeholders in preparation of KPI reports.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Coordinate performance reporting at departmental/teams level</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Maintain control of performance reports, including maintenance and updating of documents and ensuring appropriate version controls, structure and archiving;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Proactively liaise with users to co-ordinate the provision of performance information, developing and using appropriate modes of communication.</li>
            </ul>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">KPIs and Data</h4>
            <ol class="space-y-4 px-6 md:px-8 mt-4 md:mt-6 ">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Co-ordinate collection of planning, strategy and performance data;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Contribute to the evolution and development of the strategic KPIs and support the integration of KPIs and use of data across student education and research & innovation;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Maintain relationships with data providers to identify and access appropriate data for regular and ad hoc performance reporting as well as working to improve data and information quality;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Contribute to the adoption of KPIs throughout the organization and support understanding and use of KPI and benchmark data in functional units to support planning;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Maintain enterprise performance reports incorporating data from internal and external sources internal and external data;</li>
            </ol>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">Analysis, interpretation and understanding</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Analysis and interpretation of performance information at enterprise level to assess progress in implementing the enterprise’ Strategic Plan, bringing together cross-functional analysis and  planning data to provide an integrated understanding of performance and supporting identification of further improvement initiatives to inform understanding of progress;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Support use of KPIs and benchmark data at teams  and departmental  levels to establish the gaps in performance that need to be addressed in strategic actions plans submitted via the Integrated Planning Exercise.</li>
            </ul>

            <h4 class="text-grey5 text-sm lg:text-lg mt-6 md:mt-8">Other</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Contribute to the development of strategy, planning and performance skills throughoutthe organization</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Demonstrate a commitment to personal development.</li>
            </ul>

            <h4 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Qualifications and Experience</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Degree or professional qualification;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience of working with performance information and appropriate manipulation, analysis and reporting, demonstrating the ability to collate, analyse and interpret information - identifying appropriate actions;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience of working in a complex and changing environment.</li>
            </ul>

            <h4 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Skills and Knowledge</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Understanding of the role performance management plays in supporting strategy, ideally with experience of its application;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Excellent interpersonal & communication skills, including an ability to clearly and confidently communicate complex, sensitive and important information using a variety of methods;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Highly numerate, with the ability to understand, structure and analyse complex information – including ability to manipulate data using appropriate software tools.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Strong organisational skills ensuring effective planning and management of resources and structures approach to the control and management of core documents</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Good IT skills including the use of Microsoft Office (Word, Excel, PowerPoint) and a capability to learn new packages such as Microsoft Project and many more.</li>
            </ul>

            <h4 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Attributes / Qualities</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">A methodical, thorough and structured approach and the ability to provide this level of structure and clarity to a wider team;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">A confident and professional approach in working with colleagues across all disciplines and organizational levels to develop effective working relationships and collaborate with stakeholders;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Ability to accept responsibility for major tasks/projects and deliver results, often in complex and difficult situations.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Ability to work flexibly with limited direction, comfortable working under pressure with competing priorities, able to prioritize work, retaining a clear focus on outcomes;</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">A strong collaborative team ethos with the ability to work effectively with team members and commitment to the development of the team.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Degree or professional qualification;</li>
            </ul>

            <h4 class="text-grey7 text-lg lg:text-2xl mt-6 md:mt-8">Desirable</h4>
            <ul class="space-y-4 px-6 md:px-8 mt-4 md:mt-6">
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience of supporting strategy, planning and performance management in an organization.</li>
              <li class="list-disc text-sm font-light text-grey5 md:text-lg">Experience of supporting projects linked to an organization’s strategic agenda</li>
            </ul>
          </div>
       </div>
       <div class="flex justify-center mt-8 lg:mt-20 ">
          <x-partials.apply/>
        </div>
      </article>
    </div>
    
</section>
<x-partials.footer/>
@endsection