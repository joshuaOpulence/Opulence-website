@extends('layout.app')
@section('body')
{{-- hero --}}
<section class="w-full">
 <x-partials.navbar>
    <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
    <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-grey5" />
    <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-bas" />
    <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="" aClass="text-grey5" />
  </x-partials.navbar>
 <main class="px-4 py-10 md:px-12 lg:px-20 mt-20 md:mt-32 lg:mt-40 ">   
    <div class="mt-10">
      <div class="w-full">
        <img src="{{asset('asset/post.png')}}" alt="Career-section image" class="inline-flex w-full">
        <div class="w-full mt-10 md:flex items-center md:justify-between">
        <h3 class="text-grey7 text-lg lg:text-4 font-medium md:w-4/6 leading-normal">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
        <div class="flex md:block justify-between items-end">
          <p class="text-grey4 text-xs font-light order-2 lg:order-1"><span class="hidden lg:inline">PUBLISHED</span> AUG 11, 2023</p>
          <div class="flex mt-4 items-end md:items-center space-x-2.5 order-1 lg:order-2">
            <img src="{{asset('asset/editor.png')}}" alt="">
            <p class="font-light text-xs md:text-sm">Tobi Awokunle</p>
          </div>
        </div>
        </div>
      </div>
    </div> 
    
    <div class="mt-4 md:mt-6 lg:w-4/5">
      <p class="text-grey5 font-light text-sm lg:text-lg">
        Yvonne Tolu Ibitoye is the Chief Operating Officer at Opulence Capital Investments Ltd. ; a Fintech, Edtech, and Mediatech firm registered in Canada. The firm is made up of a team of technology and business experts. She is a Certified Business Analysis Professional, with a Graduate Certificate in Management, and Masters Degree in Business Administration.
      </p>
      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">Amongst her clientele is a Muliti-national organization to whom she provides Processes and Systems Optimization Services. A common remark within her clientele network is her passion for quality, excellent attention to details, and being goal oriented.
      </p>
      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">A recent innovation of her firm is VISIONARY MOMAS, a platform where she provides coaching and a digital system to moms of children between the ages of 0-12, for effective planning and building of a sustainable, stable financial future for their children.
      </p>

      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">She is passionate about aspiring entrepreneurs and startups, thus, provides advisory services, digital tools, and support to innovative minds and small businesses across the globe. The objective is to help them minimize the cost of starting a business and provide them with the structure required for sustainability and scalability.
        
      </p>

      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">Her core values are Integrity, and Quality.
      </p>

      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">More on the news at <a href="https://nyweekly.com/business/top-10-business-coaches-to-watch-out-for-in-2021/" class="underline">https://nyweekly.com/business/top-10-business-coaches-to-watch-out-for-in-2021/</a></p>

      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">All rights reserved. This material, and other digital content on this website, may not be reproduced, published, broadcast, rewritten or redistributed in whole or in part without prior express written permission from Opulence Media Team.</p>

      <p class="text-grey5 font-light text-sm lg:text-lg mt-4 md:6">Contact: mediainquiries@opulencecapitalinvestments.com</p>
    </div>

    <div class="flex items-center justify-between lg:w-4/6 mt-10 py-4">
      <button class="text-base md:text-lg text-grey4">Previous post</i></button>
      <button class="text-base md:text-lg text-black">Next post>>></i></button>
    </div>

    <div class="mt-11">
      <h4 class=" text-grey5 text-base md:text-2xl">Related posts</h4>
      <div class="mt-10 grid grid-cols-1 gap-8 md:gap-5 md:grid-cols-2 lg:grid-cols-4">
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog1.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd expands <br class="hidden md:inline"> operations into the African market.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog3.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">The ideate process in the design thinking process is the most crucial step.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div>
       <div class="w-full lg:w-[400px] blogcard flex md:flex-col md:rounded-2xl md:border">
        <div>
         <img src="{{ asset('asset/blog2.png') }}" alt="" class="h-full md:h-auto object-cover object-center">
        </div>
        <div class="p-3 md:p-4">
         <div class="flex justify-between items-center md:block mb-4">
          <span class="text-1 text-bas md:hidden">COMPANY</span>
          <p class="font-light text-grey4 text-xs">Aug 12 2023</p>
         </div>
         <h3 class="text-grey7 font-medium text-base">Opulence Capital Investments Ltd’s Chief Operating Officer mentioned on New York Weekly.</h3>
         <div class="mt-4 flex items-end md:items-start justify-between">
          <div class="md:flex items-center md:space-x-2">
           <img src="{{asset('asset/editor.png')}}" alt="blog editor image">
           <span class="text-grey5 text-1 md:text-sm">Tobi Awokunle</span>
          </div>
          <a href="{{route('post')}}" class="flex items-center">
           <span class="text-bas text-sm lg:text-base">Read more</span>
           <img src="{{asset('asset/arrowr.svg')}}" alt="" class="ml-2">
          </a>
         </div>
        </div>
       </div> 
      </div>

    <div class="mt-16 lg:w-4/5 pb-6 lg:pb-16 border-b border-d6">
      <h3 class="text-grey7 font-medium text-lg md:text-3xl lg:text-4">Comments</h3>
      <div class="mt-11 flex space-x-4 md:space-x-8">
        <div>
          <img src="{{asset('asset/commen.png')}}" alt="">
        </div>
        <div class="">
          <div class="flex justify-between md:justify-start md:space-x-5 items-center">
            <p class="text-grey7 text-sm md:text-xl">Tobi Awokunle</p>
            <p class="text-grey4 font-light text-sm md:text-base">August 11, 2023 10:41 am</p>
          </div>
          <div class="mt-4">
            <p class="text-grey5 text-base md:text-lg">I would like to thank you for the efforts you have put in penning this blog. I really hope to see the same high-grade blog posts by you in the future as well. In truth, your creative writing abilities has encouraged me to get my own website now</p>
          </div>
          <button class="bg-oran text-white px-5 md:px-10 py-1.5 md:py-3 rounded-full mt-4 md:mt-8">Reply</button>
        </div>
      </div>
    </div>
    <div class="mt-10 md:mt-16 lg:w-4/5">
      <form action="" method="get" class="w-full">
        <div class="w-full">
            <h3 class="text-grey7 font-medium text-lg md:text-3xl lg:text-4">Leave a comment</h3>
            <p class="text-grey5 text-base md:text-lg mt-4">Your email address will not be published. Required fields are marked *</p>
            <div class="lg:w-5/6 mt-8 md:mt-11">
              <label for="" class="block text-grey5 ">Comment*</label>
              <textarea required name="" id="" rows="5" class="border-2 block rounded w-full  lg:w-2/3 mt-4 border-d6 bg-bud outline-none focus:border-bas"></textarea>
            </div>
            <div class="w-full lg:w-5/6 mt-6">
              <div class="w-full lg:w-2/3 md:space-x-6 space-y-6 md:space-y-0 lg:space-x-11 flex-col md:flex-row  flex md:items-center">
                <div class="w-full md:w-1/2">
                  <label for="" class="block text-grey5 ">Name*</label>
                  <input type="text" required name="" id="" class="border-2  rounded px-5 md:px-8 py-2 md:py-3 block w-full mt-4 border-d6 bg-bud outline-none focus:border-bas">
                </div>
                <div class="w-full md:w-1/2">
                  <label for="" class="block text-grey5 ">Email*</label>
                  <input type="email" required name="" id="" class="border-2  rounded px-5 md:px-8 py-2 md:py-3 block w-full mt-3 md:mt-4 border-d6 bg-bud outline-none focus:border-bas">
                </div>
              </div>
            </div>
            <div class="lg:w-5/6 mt-6 flex items-center">
              <div class="inline-flex"><input type="checkbox" required name="" id="" class="border-2 inline-flex w-4 h-4 rounded mt-4 border-d6 outline-none focus:border-bas"></div>
              <label for="" class="text-grey5  inline-flex ml-5 text-xs md:text-sm lg:text-lg">Save my name, email, and website in this browser for the next time I comment.</label>
            </div>
        </div>
        <div class="mt-8 md:mt-10 flex justify-center md:block">
          <button class="bg-bas text-lite1 px-7 rounded-full py-2 md:py-3">Post comment</button>
        </div>
      </form>
    </div>
 </main>
</section>
<x-partials.footer/>
@endsection