@extends('layout.app')
@section('body')
<section class="w-full">
    <x-partials.navbar>
        <x-partials.link route="{{route('index')}}" label="Home" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('career')}}" label="Careers" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('blog')}}" label="Blog" liClass="md:border-r md:border-d6" aClass="text-grey5" />
        <x-partials.link route="{{route('contact')}}" label="Contact Us" liClass="bg-grey3 md:bg-transparent md:hover:bg-transparent  hover:bg-grey3" aClass="text-bas" />
    </x-partials.navbar>
    <div class="px-4 mt-28 md:mt-32 lg:mt-32 pb-10 md:px-12 lg:px-20 ">
     <div class="py-10 border-b border-bud">
      <h1 class="text-bas font-medium text-2 lg:text-4 text-center">Contact Us</h1>
      <p class="font-light text-grey5 text-base md:text-2xl text-center mt-4">Connect with us as we provide exceptional service and support</p>
     </div>
     <div class="flex w-full flex-col lg:flex-row md:mt-6 lg:mt-11 pt-8">
      <div class="w-full lg:w-2/5 bg-second px-6 py-8 md:p-16 order-2 lg:order-1">
       <div class="pb-8 border-b border-bid">
        <h2 class="text-lite1 mb-8 font-medium text-lg md:text-2">Our office address</h2>
        <p class="text-base lg:text-lg text-f8 mb-3">USA Operations</p>
        <p class="text-base text-secon mb-4">2810 N Church St 19802-4447, Wilmington, DE</p>
        <a href="tel:+1437971990" class="text-secon text-base">+1 (437) 971-3990</a>
       </div>
       <div class="py-8 border-b border-bid">
        <p class="text-base lg:text-lg text-f8 mb-3">Canadian Operations</p>
        <p class="text-base text-secon mb-4">3300 Highway 7, Suite 600, Vaughan, Ontario, Canada, L4K 4M3</p>
        <a href="tel:+1437971990" class="text-secon text-base">+1 (437) 971-3990</a>
       </div>
       <div class="pt-8">
        <p class="text-base lg:text-lg text-f8 mb-3">Nigerian Operations</p>
        <p class="text-base text-secon mb-4">Unit 4, Plot 104, Emmanuel Adiele Street, Off Mike Akhigbe Way, Jabi 240102</p>
        <a href="tel:+2348027998301" class="text-secon text-base">+ (234) 8027998301</a>
       </div>
      </div>
      <form action="" class="w-full lg:w-3/5 bg-white px-6 py-8 md:p-16 order-1 lg:order-2">
       <h3 class="text-grey7 text-2 mb-10">Send us a message</h3>
       <div>
        <label for="first-name" class="text-grey5 font-light block">First name</label>
        <input type="text" name="first-name" class="w-full lg:w-4/6 bg-bud border border-d6 py-2 px-5 mt-4 rounded focus:outline-second">
       </div>
       <div class="mt-6">
        <label for="last-name" class="text-grey5 font-light block">Last name</label>
        <input name="last-name" type="text" class="w-full lg:w-4/6 bg-bud border border-d6 py-2 px-5 mt-4 rounded focus:outline-second">
       </div>
       <div class="mt-6">
        <label for="email" class="text-grey5 font-light block">Email</label>
        <input name="email" type="email" class="w-full lg:w-4/6 bg-bud border border-d6 py-2 px-5 mt-4 rounded focus:outline-second">
       </div>
       <div class="mt-6 mb-10">
        <label for="message" class="text-grey5 font-light block">Message</label>
        <textarea name="" id="" rows="5" class="w-full lg:w-4/6 bg-bud border border-d6 py-2 px-5 mt-4 rounded focus:outline-second"></textarea>
       </div>
       <button class="bg-second text-sm md:text-base text-white py-2 px-8 md:py-3.5 mdpx-12 rounded-full ">Submit</button>
      </form>
     </div>
     <div class="w-full lg:w-4/5 mt-20">
        <div class="hidden md:block">
            <h3 class="text-bas font-medium text-2 lg:text-3">Get in touch with us</h3>
        </div>
        <div class="md:mt-10 flex flex-col md:flex-row gap-y-8 md:gap-y-16 flex-wrap">
            <div class="md:w-1/2 lg:w-1/3">
                <h4 class="tex-lg md:text-2 text-grey7 font-normal mb-3 md:mb-4">General  inquiries</h4>
                <p class="text-sm md:text-lg text-grey5 font-light mb-4 md:mb-6">Got Questions? We've Got Answers!</p>
                <a href="mailto:info@opulencecapitalinvestments.com" target="_blank" class="flex text-bas text-base md:text-lg">
                    <span>Let’s hear it</span>
                    <img src="{{asset('asset/arrowr.svg')}}" alt="arrow-icon" class="ml-2">
                </a>
            </div>
            <div class="md:w-1/2 lg:w-1/3">
                <h4 class="tex-lg md:text-2 text-grey7 font-normal mb-3 md:mb-4">Complaints</h4>
                <p class="text-sm md:text-lg text-grey5 font-light mb-4 md:mb-6">Got any complaints?</p>
                <a href="mailto:cis@opulencecapitalinvestments.com" target="_blank" class="flex text-bas text-base md:text-lg">
                    <span>Let’s hear it</span>
                    <img src="{{asset('asset/arrowr.svg')}}" alt="arrow-icon" class="ml-2">
                </a>
            </div>
            <div class="md:w-1/2 lg:w-1/3">
                <h4 class="tex-lg md:text-2 text-grey7 font-normal mb-3 md:mb-4">Tech</h4>
                <p class="text-sm md:text-lg text-grey5 font-light mb-4 md:mb-6">Have you got any technical issues?</p>
                <a href="mailto:dev@opulencecapitalinvestments.com" target="_blank" class="flex text-bas text-base md:text-lg">
                    <span>Let’s hear it</span>
                    <img src="{{asset('asset/arrowr.svg')}}" alt="arrow-icon" class="ml-2">
                </a>
            </div>
            <div class="md:w-1/2 lg:w-1/3">
                <h4 class="tex-lg md:text-2 text-grey7 font-normal mb-3 md:mb-4">Media</h4>
                <p class="text-sm md:text-lg text-grey5 font-light mb-4 md:mb-6">Got Questions? We've Got Answers!</p>
                <a href="mailto:pr@opulencecapitalinvestments.com" target="_blank" class="flex text-bas text-base md:text-lg">
                    <span>Let’s hear it</span>
                    <img src="{{asset('asset/arrowr.svg')}}" alt="arrow-icon" class="ml-2">
                </a>
            </div>
            <div class="md:w-1/2 lg:w-1/3">
                <h4 class="tex-lg md:text-2 text-grey7 font-normal mb-3 md:mb-4">Jobs & Careers</h4>
                <p class="text-sm md:text-lg text-grey5 font-light mb-4 md:mb-6">Take a look at our job openings</p>
                <a href="mailto:careers@opulencecapitalinvestments.com" target="_blank" class="flex text-bas text-base md:text-lg">
                    <span>See it</span>
                    <img src="{{asset('asset/arrowr.svg')}}" alt="arrow-icon" class="ml-2">
                </a>
            </div>
            
        </div>
     </div>
    </div>
</section>
<x-partials.footer/>
@endsection